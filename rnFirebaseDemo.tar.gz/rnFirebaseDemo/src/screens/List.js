import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import ItemComponent from '../components/ItemComponent';

import { db } from '../config';

let userDataRef = db.ref('/userdata');

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		backgroundColor: '#ebebeb'
	}
});

export default class List extends Component {
	state = {
		userData: []
	};

	componentDidMount() {
		userDataRef.on('value', snapshot => {
			let data = snapshot.val();
			let userData = Object.values(data);
			this.setState({ userData },()=>{
				alert(JSON.stringify(this.state.userData));
			});
		});
	}

	render() {
		return (
			<View style={styles.container}>
				{this.state.userData.length > 0 ? (
					<ItemComponent items={this.state.userData} />
				) : (
					<Text>No items</Text>
				)}
			</View>
		);
	}
}

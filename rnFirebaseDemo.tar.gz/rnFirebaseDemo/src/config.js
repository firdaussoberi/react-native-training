//import Firebase from 'firebase';
import firebase from '@firebase/app'
import '@firebase/auth'

var database = require('@firebase/database');

/*let config = {
	apiKey: 'AIzaSyBNVGTSNprnxeECDP8IP3HvbLSL0qK0FYk',
	authDomain: 'rnfirebase-e2de1.firebaseapp.com',
	databaseURL: 'https://rnfirebase-e2de1.firebaseio.com',
	projectId: 'rnfirebase-e2de1',
	storageBucket: 'rnfirebase-e2de1.appspot.com',
	messagingSenderId: '670572703564'
};*/

  //var config = {
  let config = {  	
    apiKey: "AIzaSyB4yjOb11T_lN5Rt45DnWth57r_AGE5uII",
    authDomain: "reactnativepractice-6017b.firebaseapp.com",
    databaseURL: "https://reactnativepractice-6017b.firebaseio.com",
    projectId: "reactnativepractice-6017b",
    storageBucket: "reactnativepractice-6017b.appspot.com",
    messagingSenderId: "478563981923",
  };
  //firebase.initializeApp(config);

let app = firebase.initializeApp(config);
export const db = app.database();



import React from "react";
import { View, Text } from "react-native";
import { Card, Button, Input } from "react-native-elements";
import { onSignIn } from "../auth";

export default class SignIn extends React.Component { 

  constructor(props) {
    super(props);

    this.state = {

    };

  }

   componentDidMount() {
   }

render(){
  return ( 
  <View style={{ paddingVertical: 20 }}>
    <Card>
      <Text>Email</Text>
      <Input placeholder="Email address..." />
      <Text>Password</Text>
      <Input secureTextEntry placeholder="Password..." />

      <Button
        buttonStyle={{ marginTop: 20 }}
        backgroundColor="#03A9F4"
        title="SIGN IN"
        onPress={() => {
          onSignIn().then(() => this.props.navigation.navigate("SignedIn"));
        }}
      />
    </Card>
  </View>
);
}
}
